from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

@dataclass
class User:
    id: int
    username: str
    role: str

@dataclass
class Product:
    id: int
    name: str
    description: str
    price: float
    category: str

@dataclass
class InventoryItem:
    id: int
    product_id: int
    product_name: str
    quantity: int
    price: float

@dataclass
class Order:
    id: int
    product_id: int
    product_name: str
    quantity: int
    from_user_id: int
    to_user_id: int
    status: str
    created_at: datetime

@dataclass
class Notification:
    id: int
    message: str
    is_read: bool
    created_at: datetime
