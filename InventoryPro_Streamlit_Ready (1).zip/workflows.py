import streamlit as st
import time
from auth import get_user_id
from database import (
    get_db_connection, get_user_id_by_role, 
    create_order, update_order_status, add_notification,
    update_inventory, get_order_details
)

def process_customer_order(customer_id, product_id, product_name, quantity):
    """Process an order from an End Customer."""
    try:
        # Find first available retailer
        retailer_id = get_user_id_by_role("Retailer")
        
        if not retailer_id:
            st.error("No retailer available to process your order.")
            return False
        
        # Create order from customer to retailer
        order_id = create_order(product_id, quantity, customer_id, retailer_id)
        
        if not order_id:
            st.error("Failed to create order. Please try again.")
            return False
        
        # Notify retailer
        add_notification(
            retailer_id, 
            f"New order received for {quantity} x {product_name}"
        )
        
        # Notify customer
        add_notification(
            customer_id, 
            f"Your order for {quantity} x {product_name} has been placed successfully"
        )
        
        return True
    except Exception as e:
        st.error(f"Error processing customer order: {e}")
        return False

def process_retailer_order(order_id):
    """Process an order received by a Retailer."""
    order = get_order_details(order_id)
    
    if not order:
        st.error("Order not found")
        return False
    
    # Check retailer's inventory
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND product_id = ?",
            (order["to_user_id"], order["product_id"])
        )
        
        inventory = cursor.fetchone()
        conn.close()
        
        quantity = inventory['quantity'] if inventory else 0
        
        if inventory and quantity >= order["quantity"]:
            # Retailer has enough stock
            # Update inventory
            update_inventory(order["to_user_id"], order["product_id"], -order["quantity"])
            
            # Update order status
            update_order_status(order_id, "completed")
            
            # Notify customer
            add_notification(
                order["from_user_id"], 
                f"Your order for {order['quantity']} x {order['name']} has been completed"
            )
            
            return True
        else:
            # Retailer needs to order from wholesaler
            wholesaler_id = get_user_id_by_role("Wholesaler")
            
            if not wholesaler_id:
                st.error("No wholesaler available to fulfill the order.")
                return False
            
            # Create order from retailer to wholesaler
            new_order_id = create_order(
                order["product_id"], 
                order["quantity"], 
                order["to_user_id"], 
                wholesaler_id
            )
            
            # Update original order status
            update_order_status(order_id, "pending_stock")
            
            # Notify wholesaler
            add_notification(
                wholesaler_id, 
                f"New stock request received for {order['quantity']} x {order['name']}"
            )
            
            # Notify customer about delay
            add_notification(
                order["from_user_id"], 
                f"Your order for {order['quantity']} x {order['name']} is being processed but awaiting stock"
            )
            
            return True
    except Exception as e:
        st.error(f"Error processing retailer order: {e}")
        if conn:
            conn.close()
        return False

def process_wholesaler_order(order_id):
    """Process an order received by a Wholesaler."""
    order = get_order_details(order_id)
    
    if not order:
        st.error("Order not found")
        return False
    
    # Check wholesaler's inventory
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND product_id = ?",
            (order["to_user_id"], order["product_id"])
        )
        
        inventory = cursor.fetchone()
        conn.close()
        
        quantity = inventory['quantity'] if inventory else 0
        
        if inventory and quantity >= order["quantity"]:
            # Wholesaler has enough stock
            # Update inventory
            update_inventory(order["to_user_id"], order["product_id"], -order["quantity"])
            
            # Update order status
            update_order_status(order_id, "completed")
            
            # Update retailer's inventory
            update_inventory(order["from_user_id"], order["product_id"], order["quantity"])
            
            # Notify retailer
            add_notification(
                order["from_user_id"], 
                f"Your stock request for {order['quantity']} x {order['name']} has been fulfilled"
            )
            
            # Find original customer order
            conn = None
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                
                cursor.execute(
                    "SELECT id FROM orders WHERE to_user_id = ? AND product_id = ? AND status = 'pending_stock' LIMIT 1",
                    (order["from_user_id"], order["product_id"])
                )
                
                customer_order = cursor.fetchone()
                conn.close()
                
                if customer_order:
                    # Process the original customer order now that stock is available
                    process_retailer_order(customer_order['id'])
            except Exception as e:
                print(f"Error finding original customer order: {e}")
                if conn:
                    conn.close()
            
            return True
        else:
            # Wholesaler needs to order from manufacturer
            manufacturer_id = get_user_id_by_role("Manufacturer")
            
            if not manufacturer_id:
                st.error("No manufacturer available to produce the item.")
                return False
            
            # Create order from wholesaler to manufacturer
            new_order_id = create_order(
                order["product_id"], 
                order["quantity"], 
                order["to_user_id"], 
                manufacturer_id
            )
            
            # Update original order status
            update_order_status(order_id, "pending_manufacturing")
            
            # Notify manufacturer
            add_notification(
                manufacturer_id, 
                f"New manufacturing request received for {order['quantity']} x {order['name']}"
            )
            
            return True
    except Exception as e:
        st.error(f"Error processing wholesaler order: {e}")
        if conn:
            conn.close()
        return False

def manufacture_product(order_id):
    """Manufacturer produces products for an order."""
    order = get_order_details(order_id)
    
    if not order:
        st.error("Order not found")
        return False
    
    try:
        # Simulate manufacturing process
        with st.spinner("Manufacturing in progress..."):
            time.sleep(2)  # Simulate manufacturing time
        
        # Update order status
        update_order_status(order_id, "completed")
        
        # Update wholesaler's inventory
        update_inventory(order["from_user_id"], order["product_id"], order["quantity"])
        
        # Notify wholesaler
        add_notification(
            order["from_user_id"], 
            f"Manufacturing complete for {order['quantity']} x {order['name']}"
        )
        
        # Find wholesaler's pending order to retailer
        conn = None
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute(
                "SELECT id FROM orders WHERE from_user_id = ? AND product_id = ? AND status = 'pending_manufacturing' LIMIT 1",
                (order["from_user_id"], order["product_id"])
            )
            
            wholesaler_order = cursor.fetchone()
            conn.close()
            
            if wholesaler_order:
                # Process the wholesaler's order to retailer now that stock is available
                process_wholesaler_order(wholesaler_order['id'])
        except Exception as e:
            print(f"Error finding pending wholesaler order: {e}")
            if conn:
                conn.close()
        
        return True
    except Exception as e:
        st.error(f"Error manufacturing product: {e}")
        return False
