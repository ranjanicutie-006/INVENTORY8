import hashlib
import sqlite3
from database import get_db_connection

def hash_password(password):
    """Hash a password for storing."""
    return hashlib.sha256(password.encode()).hexdigest()

def authenticate_user(username, password):
    """Authenticate a user with username and password."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get user from database
        cursor.execute("SELECT password, role FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        
        conn.close()
        
        # If user exists and password matches
        if user and user['password'] == hash_password(password):
            return True, user['role']
        
        return False, None
    except Exception as e:
        print(f"Error authenticating user: {e}")
        if conn:
            conn.close()
        return False, None

def register_user(username, password, role):
    """Register a new user with username, password, and role."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        hashed_password = hash_password(password)
        cursor.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, hashed_password, role)
        )
        conn.commit()
        conn.close()
        return True
    except sqlite3.Error as e:
        print(f"Error registering user: {e}")
        if conn:
            conn.rollback()
            conn.close()
        return False
    except Exception as e:
        print(f"Unexpected error during registration: {e}")
        if conn:
            conn.rollback()
            conn.close()
        return False

def is_username_taken(username):
    """Check if username is already taken."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        result = cursor.fetchone()
        count = result['COUNT(*)'] if result else 0
        
        conn.close()
        
        return count > 0
    except Exception as e:
        print(f"Error checking username: {e}")
        if conn:
            conn.close()
        return False

def get_user_id(username):
    """Get user ID from username."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
        user_id = cursor.fetchone()
        
        conn.close()
        
        return user_id['id'] if user_id else None
    except Exception as e:
        print(f"Error getting user ID: {e}")
        if conn:
            conn.close()
        return None
