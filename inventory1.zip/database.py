import sqlite3
import os
import time

# SQLite database file
DB_FILE = 'inventory_management.db'

def dict_factory(cursor, row):
    """Create dictionary from database results."""
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

def get_db_connection():
    """Create a connection to the SQLite database."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = dict_factory
    return conn

def get_cursor(conn):
    """Get a cursor from connection."""
    return conn.cursor()

def initialize_db():
    """Initialize the database with required tables if they don't exist."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Create users table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
        ''')
        
        # Create products table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            category TEXT
        )
        ''')
        
        # Create inventory table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (product_id) REFERENCES products (id),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
        ''')
        
        # Create orders table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            from_user_id INTEGER NOT NULL,
            to_user_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products (id),
            FOREIGN KEY (from_user_id) REFERENCES users (id),
            FOREIGN KEY (to_user_id) REFERENCES users (id)
        )
        ''')
        
        # Create notifications table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
        ''')
        
        conn.commit()
        
        # Insert default products if none exist
        try:
            cursor.execute("SELECT COUNT(*) FROM products")
            result = cursor.fetchone()
            product_count = result['COUNT(*)'] if result is not None else 0
            
            if product_count == 0:
                products = [
                    ('Smartphone', 'Latest model smartphone', 699.99, 'Electronics'),
                    ('Laptop', 'High-performance laptop', 1299.99, 'Electronics'),
                    ('Desk Chair', 'Ergonomic office chair', 199.99, 'Furniture'),
                    ('Coffee Maker', 'Automatic coffee brewing machine', 89.99, 'Appliances'),
                    ('Headphones', 'Noise-cancelling headphones', 149.99, 'Electronics'),
                    ('Tablet', '10-inch tablet with accessories', 349.99, 'Electronics'),
                    ('Blender', 'High-speed blender for smoothies', 79.99, 'Appliances'),
                    ('Desk Lamp', 'LED desk lamp with adjustable brightness', 49.99, 'Furniture'),
                    ('Wireless Mouse', 'Ergonomic wireless mouse', 29.99, 'Electronics'),
                    ('Keyboard', 'Mechanical keyboard with RGB lighting', 89.99, 'Electronics')
                ]
                
                for product in products:
                    try:
                        # First check if product exists
                        cursor.execute("SELECT COUNT(*) FROM products WHERE name = ?", (product[0],))
                        exists = cursor.fetchone()['COUNT(*)'] > 0
                        
                        if not exists:
                            cursor.execute('''
                            INSERT INTO products (name, description, price, category)
                            VALUES (?, ?, ?, ?)
                            ''', product)
                    except Exception as e:
                        print(f"Error inserting product {product[0]}: {e}")
                        conn.rollback()
                
                conn.commit()
        except Exception as e:
            print(f"Error handling product insertion: {e}")
            if conn:
                conn.rollback()
        
        if conn:
            conn.close()
    except Exception as e:
        print(f"Database initialization error: {e}")
        if conn:
            try:
                conn.rollback()
                conn.close()
            except:
                pass

def get_user_role(username):
    """Get user role from username."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
        role = cursor.fetchone()
        
        conn.close()
        
        return role['role'] if role else None
    except Exception as e:
        print(f"Error getting user role: {e}")
        if conn:
            try:
                conn.close()
            except:
                pass
        return None

def get_user_id_by_role(role):
    """Get a user ID by role (for finding first available user with that role)."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        cursor.execute("SELECT id FROM users WHERE role = ? LIMIT 1", (role,))
        user_id = cursor.fetchone()
        
        conn.close()
        
        return user_id['id'] if user_id else None
    except Exception as e:
        print(f"Error getting user ID by role: {e}")
        if conn:
            try:
                conn.close()
            except:
                pass
        return None

def add_notification(user_id, message):
    """Add a notification for a user."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO notifications (user_id, message) VALUES (?, ?)",
            (user_id, message)
        )
        
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error adding notification: {e}")
        if conn:
            try:
                conn.rollback()
                conn.close()
            except:
                pass

def get_products():
    """Get all products from the database."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()
        
        conn.close()
        
        return products
    except Exception as e:
        print(f"Error getting products: {e}")
        if conn:
            try:
                conn.close()
            except:
                pass
        return []

def get_inventory(user_id):
    """Get inventory for a specific user."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        cursor.execute('''
        SELECT i.id, p.id AS product_id, p.name, p.description, p.price, i.quantity
        FROM inventory i
        JOIN products p ON i.product_id = p.id
        WHERE i.user_id = ?
        ''', (user_id,))
        
        inventory = cursor.fetchall()
        
        conn.close()
        
        return inventory
    except Exception as e:
        print(f"Error getting inventory: {e}")
        if conn:
            try:
                conn.close()
            except:
                pass
        return []

def update_inventory(user_id, product_id, quantity):
    """Update or add inventory for a user."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        # Check if product exists in inventory
        cursor.execute(
            "SELECT id, quantity FROM inventory WHERE user_id = ? AND product_id = ?",
            (user_id, product_id)
        )
        
        inventory_item = cursor.fetchone()
        
        if inventory_item:
            # Update existing inventory
            new_quantity = inventory_item['quantity'] + quantity
            if new_quantity < 0:
                new_quantity = 0
                
            cursor.execute(
                "UPDATE inventory SET quantity = ? WHERE id = ?",
                (new_quantity, inventory_item['id'])
            )
        else:
            # Add new inventory item
            if quantity > 0:
                cursor.execute(
                    "INSERT INTO inventory (product_id, user_id, quantity) VALUES (?, ?, ?)",
                    (product_id, user_id, quantity)
                )
        
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error updating inventory: {e}")
        if conn:
            try:
                conn.rollback()
                conn.close()
            except:
                pass

def get_orders(user_id, is_sender=False):
    """Get orders for a user (received by default, sent if is_sender=True)."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        if is_sender:
            # Get orders sent by user
            cursor.execute('''
            SELECT o.id, p.name, o.quantity, u.username AS recipient, o.status, o.created_at
            FROM orders o
            JOIN products p ON o.product_id = p.id
            JOIN users u ON o.to_user_id = u.id
            WHERE o.from_user_id = ?
            ORDER BY o.created_at DESC
            ''', (user_id,))
        else:
            # Get orders received by user
            cursor.execute('''
            SELECT o.id, p.name, o.quantity, u.username AS sender, o.status, o.created_at
            FROM orders o
            JOIN products p ON o.product_id = p.id
            JOIN users u ON o.from_user_id = u.id
            WHERE o.to_user_id = ?
            ORDER BY o.created_at DESC
            ''', (user_id,))
        
        orders = cursor.fetchall()
        
        conn.close()
        
        return orders
    except Exception as e:
        print(f"Error getting orders: {e}")
        if conn:
            try:
                conn.close()
            except:
                pass
        return []

def get_notifications(user_id):
    """Get notifications for a user."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        cursor.execute('''
        SELECT id, message, is_read, created_at
        FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        ''', (user_id,))
        
        notifications = cursor.fetchall()
        
        conn.close()
        
        return notifications
    except Exception as e:
        print(f"Error getting notifications: {e}")
        if conn:
            try:
                conn.close()
            except:
                pass
        return []

def mark_notification_as_read(notification_id):
    """Mark a notification as read."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "UPDATE notifications SET is_read = 1 WHERE id = ?",
            (notification_id,)
        )
        
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error marking notification as read: {e}")
        try:
            if conn:
                conn.rollback()
                conn.close()
        except:
            pass

def create_order(product_id, quantity, from_user_id, to_user_id, status="pending"):
    """Create a new order."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO orders (product_id, quantity, from_user_id, to_user_id, status) VALUES (?, ?, ?, ?, ?)",
            (product_id, quantity, from_user_id, to_user_id, status)
        )
        
        # Get the last inserted ID for SQLite
        order_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return order_id
    except Exception as e:
        print(f"Error creating order: {e}")
        try:
            if conn:
                conn.rollback()
                conn.close()
        except:
            pass
        return None

def update_order_status(order_id, status):
    """Update the status of an order."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "UPDATE orders SET status = ? WHERE id = ?",
            (status, order_id)
        )
        
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error updating order status: {e}")
        try:
            if conn:
                conn.rollback()
                conn.close()
        except:
            pass

def get_order_details(order_id):
    """Get details of a specific order."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = get_cursor(conn)
        
        cursor.execute('''
        SELECT o.id, p.id AS product_id, p.name, o.quantity, 
               o.from_user_id, o.to_user_id, o.status, o.created_at
        FROM orders o
        JOIN products p ON o.product_id = p.id
        WHERE o.id = ?
        ''', (order_id,))
        
        order = cursor.fetchone()
        
        conn.close()
        
        return order
    except Exception as e:
        print(f"Error getting order details: {e}")
        try:
            if conn:
                conn.close()
        except:
            pass
        return None
