import streamlit as st
import time
import pandas as pd
from auth import get_user_id
from database import (
    get_inventory, get_products, get_user_id_by_role, 
    create_order, get_orders, get_notifications, mark_notification_as_read,
    add_notification
)
from workflows import (
    process_customer_order, process_retailer_order, 
    process_wholesaler_order, manufacture_product
)

def show_sidebar():
    """Display the sidebar navigation."""
    st.sidebar.title(f"👤 {st.session_state.username}")
    st.sidebar.subheader(f"Role: {st.session_state.role}")
    
    # Add role-specific icon
    if st.session_state.role == "End Customer":
        role_icon = "🛒"
    elif st.session_state.role == "Retailer":
        role_icon = "🏪"
    elif st.session_state.role == "Wholesaler":
        role_icon = "🏭"
    elif st.session_state.role == "Manufacturer":
        role_icon = "⚙️"
    
    st.sidebar.markdown(f"## {role_icon} {st.session_state.role} Dashboard")
    
    st.sidebar.markdown("---")
    
    # Navigation
    if st.sidebar.button("📊 Dashboard"):
        st.session_state.current_page = "dashboard"
        st.rerun()
    
    # Only show Inventory for non-customer roles
    if st.session_state.role != "End Customer":
        if st.sidebar.button("📦 Inventory"):
            st.session_state.current_page = "inventory"
            st.rerun()
    
    if st.session_state.role == "End Customer":
        # Replace Inventory with Order History for End Customers
        if st.sidebar.button("📜 Order History"):
            st.session_state.current_page = "orders"
            st.rerun()
    else:
        if st.sidebar.button("📋 Orders"):
            st.session_state.current_page = "orders"
            st.rerun()
    
    if st.sidebar.button("🔔 Notifications"):
        st.session_state.current_page = "notifications"
        st.rerun()
    
    st.sidebar.markdown("---")
    
    if st.sidebar.button("🚪 Logout"):
        st.session_state.current_page = "logout"
        st.rerun()

def render_dashboard(role, username):
    """Render the dashboard based on user role."""
    user_id = get_user_id(username)
    
    st.title(f"📊 {role} Dashboard")
    
    # Key metrics
    col1, col2, col3 = st.columns(3)
    
    # Get inventory data
    inventory = get_inventory(user_id)
    total_items = sum(item["quantity"] for item in inventory) if inventory else 0
    
    # Get orders data
    received_orders = get_orders(user_id, is_sender=False)
    sent_orders = get_orders(user_id, is_sender=True)
    
    # Get notifications
    notifications = get_notifications(user_id)
    unread_notifications = sum(1 for n in notifications if not n["is_read"])
    
    with col1:
        st.metric(label="Total Inventory Items", value=total_items)
    
    with col2:
        st.metric(label="Pending Orders", value=len([o for o in received_orders if o["status"] != "completed"]))
    
    with col3:
        st.metric(label="Unread Notifications", value=unread_notifications)
    
    st.markdown("---")
    
    # Role-specific ordering and dashboard
    if role == "End Customer":
        # Place order section
        st.subheader("🛒 Place a New Order from Retailer")
        
        # Get retailer
        retailer_id = get_user_id_by_role("Retailer")
        if not retailer_id:
            st.warning("No retailers available in the system.")
        else:
            available_products = get_products()
            
            if available_products:
                product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
                selected_product_name = st.selectbox("Select Product", list(product_options.keys()))
                
                selected_product = product_options[selected_product_name]
                quantity = st.number_input("Quantity", min_value=1, max_value=100, value=1)
                
                if st.button("Place Order"):
                    success = process_customer_order(
                        user_id, 
                        selected_product["id"], 
                        selected_product["name"],
                        quantity
                    )
                    
                    if success:
                        st.success(f"Order placed successfully for {quantity} x {selected_product['name']}")
                        time.sleep(1)
                        st.rerun()
            else:
                st.info("No products available at the moment.")
                
    elif role == "Retailer":
        # Place Wholesale Order section
        st.subheader("🛒 Order Products from Wholesaler")
        
        # Get wholesaler
        wholesaler_id = get_user_id_by_role("Wholesaler")
        if not wholesaler_id:
            st.warning("No wholesalers available in the system.")
        else:
            available_products = get_products()
            
            if available_products:
                product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
                selected_product_name = st.selectbox("Select Product", list(product_options.keys()))
                
                selected_product = product_options[selected_product_name]
                quantity = st.number_input("Quantity", min_value=1, max_value=500, value=10)
                
                if st.button("Place Wholesale Order"):
                    # Create order directly to wholesaler
                    order_id = create_order(
                        selected_product["id"], 
                        quantity, 
                        user_id, 
                        wholesaler_id
                    )
                    
                    # Notify wholesaler
                    add_notification(
                        wholesaler_id, 
                        f"New stock request received for {quantity} x {selected_product['name']}"
                    )
                    
                    st.success(f"Order placed successfully for {quantity} x {selected_product['name']}")
                    time.sleep(1)
                    st.rerun()
            else:
                st.info("No products available at the moment.")
        
        # Dashboard info
        st.markdown("---")
        st.subheader("📦 Latest Inventory")
        if inventory:
            inventory_df = pd.DataFrame(inventory)
            inventory_df = inventory_df[["name", "quantity", "price"]]
            inventory_df.columns = ["Product", "Quantity", "Unit Price ($)"]
            st.dataframe(inventory_df)
        else:
            st.info("No inventory items available.")
        
        st.subheader("📋 Recent Orders")
        if received_orders:
            orders_df = pd.DataFrame(received_orders[:5])  # Show only 5 most recent orders
            orders_df = orders_df[["name", "quantity", "sender", "status"]]
            orders_df.columns = ["Product", "Quantity", "Customer", "Status"]
            st.dataframe(orders_df)
        else:
            st.info("No recent orders.")
                
    elif role == "Wholesaler":
        # Place Manufacturing Order section
        st.subheader("🏭 Order Products from Manufacturer")
        
        # Get manufacturer
        manufacturer_id = get_user_id_by_role("Manufacturer")
        if not manufacturer_id:
            st.warning("No manufacturers available in the system.")
        else:
            available_products = get_products()
            
            if available_products:
                product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
                selected_product_name = st.selectbox("Select Product", list(product_options.keys()))
                
                selected_product = product_options[selected_product_name]
                quantity = st.number_input("Quantity", min_value=1, max_value=1000, value=50)
                
                if st.button("Request Manufacturing"):
                    # Create order directly to manufacturer
                    order_id = create_order(
                        selected_product["id"], 
                        quantity, 
                        user_id, 
                        manufacturer_id
                    )
                    
                    # Notify manufacturer
                    add_notification(
                        manufacturer_id, 
                        f"New manufacturing request received for {quantity} x {selected_product['name']}"
                    )
                    
                    st.success(f"Manufacturing request placed successfully for {quantity} x {selected_product['name']}")
                    time.sleep(1)
                    st.rerun()
            else:
                st.info("No products available at the moment.")
        
        # Dashboard info
        st.markdown("---")
        st.subheader("📦 Latest Inventory")
        if inventory:
            inventory_df = pd.DataFrame(inventory)
            inventory_df = inventory_df[["name", "quantity", "price"]]
            inventory_df.columns = ["Product", "Quantity", "Unit Price ($)"]
            st.dataframe(inventory_df)
        else:
            st.info("No inventory items available.")
        
        st.subheader("📋 Recent Orders")
        if received_orders:
            orders_df = pd.DataFrame(received_orders[:5])  # Show only 5 most recent orders
            orders_df = orders_df[["name", "quantity", "sender", "status"]]
            orders_df.columns = ["Product", "Quantity", "Retailer", "Status"]
            st.dataframe(orders_df)
        else:
            st.info("No recent orders.")
    
    elif role == "Manufacturer":
        # Dashboard info
        st.subheader("⚙️ Manufacturing Queue")
        if received_orders:
            orders_df = pd.DataFrame(received_orders)
            orders_df = orders_df[["name", "quantity", "sender", "status"]]
            orders_df.columns = ["Product", "Quantity", "Wholesaler", "Status"]
            st.dataframe(orders_df)
        else:
            st.info("No manufacturing requests at the moment.")
    
    # Show latest notifications for all roles
    st.markdown("---")
    st.subheader("🔔 Latest Notifications")
    
    if notifications:
        for notification in notifications[:3]:  # Show only 3 most recent notifications
            if notification["is_read"]:
                st.info(notification["message"])
            else:
                st.success(notification["message"] + " (New)")
        
        if len(notifications) > 3:
            st.text(f"+ {len(notifications) - 3} more notifications")
    else:
        st.info("No notifications.")

def render_inventory(role, username):
    """Render the inventory page."""
    user_id = get_user_id(username)
    
    st.title("📦 Inventory Management")
    
    inventory = get_inventory(user_id)
    
    # Allow adding inventory for non-customer roles
    if role != "End Customer":
        st.subheader("Add New Inventory")
        
        col1, col2 = st.columns(2)
        
        with col1:
            available_products = get_products()
            product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
            selected_product_name = st.selectbox("Select Product", list(product_options.keys()))
            selected_product = product_options[selected_product_name]
        
        with col2:
            quantity = st.number_input("Quantity", min_value=1, max_value=1000, value=10)
        
        if st.button("Add to Inventory"):
            from database import update_inventory
            update_inventory(user_id, selected_product["id"], quantity)
            st.success(f"Added {quantity} x {selected_product['name']} to inventory")
            time.sleep(1)
            st.rerun()
    
    st.markdown("---")
    st.subheader("Current Inventory")
    
    if inventory:
        for item in inventory:
            col1, col2, col3 = st.columns([3, 1, 1])
            
            with col1:
                st.write(f"**{item['name']}**")
                st.write(f"Price: ${item['price']:.2f}")
            
            with col2:
                # Set color based on quantity
                if item['quantity'] < 5:
                    color = "red"
                elif item['quantity'] < 20:
                    color = "orange"
                else:
                    color = "green"
                
                st.markdown(f"<h3 style='color: {color};'>{item['quantity']} units</h3>", unsafe_allow_html=True)
            
            with col3:
                # Progress bar visualization
                max_quantity = 100  # Assume 100 as max for visualization
                progress_value = min(item['quantity'] / max_quantity, 1.0)
                st.progress(progress_value)
            
            st.markdown("---")
    else:
        if role == "End Customer":
            st.info("As an End Customer, you don't manage inventory.")
        else:
            st.info("No inventory items available. Add some using the form above.")

def render_orders(role, username):
    """Render the orders page."""
    user_id = get_user_id(username)
    
    # Different title for End Customers
    if role == "End Customer":
        st.title("📜 Order History")
    else:
        st.title("📋 Orders Management")
    
    # Custom view for End Customers
    if role == "End Customer":
        # Get all orders placed by this customer
        sent_orders = get_orders(user_id, is_sender=True)
        
        if sent_orders:
            st.subheader("Your Orders")
            
            # Create columns for the table header
            col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
            with col1:
                st.markdown("**Product**")
            with col2:
                st.markdown("**Quantity**")
            with col3:
                st.markdown("**Retailer**")
            with col4:
                st.markdown("**Status**")
            
            st.markdown("---")
            
            # Show all orders with status indication
            for order in sent_orders:
                col1, col2, col3, col4 = st.columns([2, 1, 1, 1])
                
                with col1:
                    st.write(f"{order['name']}")
                
                with col2:
                    st.write(f"{order['quantity']}")
                
                with col3:
                    st.write(f"{order['recipient']}")
                
                with col4:
                    status = order['status']
                    if status == "completed":
                        st.success("Completed")
                    elif status == "pending":
                        st.warning("Pending")
                    elif status == "pending_stock":
                        st.info("Awaiting Stock")
                    elif status == "pending_manufacturing":
                        st.info("Awaiting Manufacturing")
                    else:
                        st.write(status)
                
                st.markdown("---")
        else:
            st.info("You haven't placed any orders yet.")
            
        # Add a section to place new orders
        st.markdown("## 🛒 Place a New Order")
        
        # Get retailer
        retailer_id = get_user_id_by_role("Retailer")
        if not retailer_id:
            st.warning("No retailers available in the system.")
        else:
            available_products = get_products()
            
            if available_products:
                product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
                selected_product_name = st.selectbox("Select Product", list(product_options.keys()))
                
                selected_product = product_options[selected_product_name]
                quantity = st.number_input("Quantity", min_value=1, max_value=100, value=1)
                
                if st.button("Place Order"):
                    success = process_customer_order(
                        user_id, 
                        selected_product["id"], 
                        selected_product["name"],
                        quantity
                    )
                    
                    if success:
                        st.success(f"Order placed successfully for {quantity} x {selected_product['name']}")
                        time.sleep(1)
                        st.rerun()
            else:
                st.info("No products available at the moment.")
    else:
        # Original order management for other roles
        tab1, tab2 = st.tabs(["Received Orders", "Sent Orders"])
        
        with tab1:
            received_orders = get_orders(user_id, is_sender=False)
            
            if received_orders:
                for order in received_orders:
                    col1, col2, col3 = st.columns([3, 2, 2])
                    
                    with col1:
                        st.write(f"**Order #{order['id']}**: {order['quantity']} x {order['name']}")
                        st.write(f"From: {order['sender']}")
                    
                    with col2:
                        status = order['status']
                        if status == "completed":
                            st.success("Completed")
                        elif status == "pending":
                            st.warning("Pending")
                        elif status == "pending_stock":
                            st.info("Awaiting Stock")
                        elif status == "pending_manufacturing":
                            st.info("Awaiting Manufacturing")
                        else:
                            st.write(status)
                    
                    with col3:
                        if status != "completed":
                            if role == "Retailer":
                                if st.button(f"Process Order #{order['id']}", key=f"process_{order['id']}"):
                                    success = process_retailer_order(order['id'])
                                    if success:
                                        st.success("Order processed successfully")
                                        time.sleep(1)
                                        st.rerun()
                            
                            elif role == "Wholesaler":
                                if st.button(f"Process Order #{order['id']}", key=f"process_{order['id']}"):
                                    success = process_wholesaler_order(order['id'])
                                    if success:
                                        st.success("Order processed successfully")
                                        time.sleep(1)
                                        st.rerun()
                            
                            elif role == "Manufacturer":
                                if st.button(f"Manufacture #{order['id']}", key=f"process_{order['id']}"):
                                    success = manufacture_product(order['id'])
                                    if success:
                                        st.success("Manufacturing completed successfully")
                                        time.sleep(1)
                                        st.rerun()
                    
                    st.markdown("---")
            else:
                st.info("No orders received.")
        
        with tab2:
            sent_orders = get_orders(user_id, is_sender=True)
            
            if sent_orders:
                for order in sent_orders:
                    col1, col2 = st.columns([3, 2])
                    
                    with col1:
                        st.write(f"**Order #{order['id']}**: {order['quantity']} x {order['name']}")
                        st.write(f"To: {order['recipient']}")
                    
                    with col2:
                        status = order['status']
                        if status == "completed":
                            st.success("Completed")
                        elif status == "pending":
                            st.warning("Pending")
                        elif status == "pending_stock":
                            st.info("Awaiting Stock")
                        elif status == "pending_manufacturing":
                            st.info("Awaiting Manufacturing")
                        else:
                            st.write(status)
                    
                    st.markdown("---")
            else:
                st.info("No orders sent.")
    
    # Show a form for placing orders for non-End Customer roles
    if role != "End Customer":
        st.markdown("---")
        
        if role == "Retailer":
            st.subheader("🛒 Order Products from Wholesaler")
            
            # Get wholesaler
            wholesaler_id = get_user_id_by_role("Wholesaler")
            if not wholesaler_id:
                st.warning("No wholesalers available in the system.")
            else:
                available_products = get_products()
                
                if available_products:
                    product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
                    selected_product_name = st.selectbox("Select Product", list(product_options.keys()), key="order_product")
                    
                    selected_product = product_options[selected_product_name]
                    quantity = st.number_input("Quantity", min_value=1, max_value=500, value=10, key="order_quantity")
                    
                    if st.button("Place Wholesale Order", key="place_order"):
                        # Create order directly to wholesaler
                        order_id = create_order(
                            selected_product["id"], 
                            quantity, 
                            user_id, 
                            wholesaler_id
                        )
                        
                        # Notify wholesaler
                        add_notification(
                            wholesaler_id, 
                            f"New stock request received for {quantity} x {selected_product['name']}"
                        )
                        
                        st.success(f"Order placed successfully for {quantity} x {selected_product['name']}")
                        time.sleep(1)
                        st.rerun()
                else:
                    st.info("No products available at the moment.")
                    
        elif role == "Wholesaler":
            st.subheader("🏭 Order Products from Manufacturer")
            
            # Get manufacturer
            manufacturer_id = get_user_id_by_role("Manufacturer")
            if not manufacturer_id:
                st.warning("No manufacturers available in the system.")
            else:
                available_products = get_products()
                
                if available_products:
                    product_options = {f"{p['name']} (${p['price']})": p for p in available_products}
                    selected_product_name = st.selectbox("Select Product", list(product_options.keys()), key="order_product")
                    
                    selected_product = product_options[selected_product_name]
                    quantity = st.number_input("Quantity", min_value=1, max_value=1000, value=50, key="order_quantity")
                    
                    if st.button("Request Manufacturing", key="place_order"):
                        # Create order directly to manufacturer
                        order_id = create_order(
                            selected_product["id"], 
                            quantity, 
                            user_id, 
                            manufacturer_id
                        )
                        
                        # Notify manufacturer
                        add_notification(
                            manufacturer_id, 
                            f"New manufacturing request received for {quantity} x {selected_product['name']}"
                        )
                        
                        st.success(f"Manufacturing request placed successfully for {quantity} x {selected_product['name']}")
                        time.sleep(1)
                        st.rerun()
                else:
                    st.info("No products available at the moment.")

def render_notifications(username):
    """Render the notifications page."""
    user_id = get_user_id(username)
    
    st.title("🔔 Notifications")
    
    notifications = get_notifications(user_id)
    
    if notifications:
        for notification in notifications:
            col1, col2 = st.columns([4, 1])
            
            with col1:
                if notification["is_read"]:
                    st.info(notification["message"])
                else:
                    st.success(f"{notification['message']} (New)")
                st.caption(f"Received: {notification['created_at']}")
            
            with col2:
                if not notification["is_read"]:
                    if st.button("Mark as Read", key=f"read_{notification['id']}"):
                        mark_notification_as_read(notification["id"])
                        st.rerun()
            
            st.markdown("---")
    else:
        st.info("No notifications.")
